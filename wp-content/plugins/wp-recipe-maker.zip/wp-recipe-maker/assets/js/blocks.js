if (!global._babelPolyfill) { require('babel-polyfill'); }
import './blocks/jump-to-recipe';
import './blocks/jump-to-video';
import './blocks/nutrition-label';
import './blocks/print-recipe';
import './blocks/recipe';
import './blocks/recipe-roundup';