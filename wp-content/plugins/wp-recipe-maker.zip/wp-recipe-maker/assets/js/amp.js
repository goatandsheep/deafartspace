if (!global._babelPolyfill) { require('babel-polyfill'); }
if (!global._babelPolyfill) { require('babel-polyfill'); }
import '../css/public/snippets.scss';
import '../css/public/template_reset.scss';
import '../css/shortcodes/shortcodes.scss';
import '../css/public/amp.scss';