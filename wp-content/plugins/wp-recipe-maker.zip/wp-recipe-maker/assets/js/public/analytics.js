window.WPRecipeMaker.analytics = {
	setMeta: ( meta ) => {
		if ( wprm_public.settings.analytics_enabled ) {
			document.cookie = 'wprm_analytics_meta=' + JSON.stringify( meta ) + ';path=/;max-age=' + ( 60 * 60 * 24 );
		}
	},
};
