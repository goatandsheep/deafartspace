<?php
/**
 * Responsible for the recipe analytics.
 *
 * @link       http://bootstrapped.ventures
 * @since      6.5.0
 *
 * @package    WP_Recipe_Maker
 * @subpackage WP_Recipe_Maker/includes/public
 */

/**
 * Responsible for the recipe analytics.
 *
 * @since      6.5.0
 * @package    WP_Recipe_Maker
 * @subpackage WP_Recipe_Maker/includes/public
 * @author     Brecht Vandersmissen <brecht@bootstrapped.ventures>
 */
class WPRM_Analytics {

	/**
	 * Register a specific action.
	 *
	 * @since    6.5.0
	 * @param    int $recipe_id Recipe to register the action for.
	 * @param    int $post_id 	Post to register the action for.
	 * @param    string $type 	Type of action to register.
	 * @param    mixed $meta 	Meta for the action.
	 */
	public static function register_action( $recipe_id, $post_id, $type, $meta = array() ) {
		if ( WPRM_Settings::get( 'analytics_enabled' ) ) {
			// Maybe add/change information.
			$frontend_meta = self::get_frontend_meta();

			switch ( $type ) {
				case 'print':
					$post_id = isset( $frontend_meta['post_id'] ) ? intval( $frontend_meta['post_id'] ) : $post_id;
					$meta['location'] = isset( $frontend_meta['location'] ) ? sanitize_key( $frontend_meta['location'] ) : 'unknown';
					break;
			}

			// Construct and register action.
			$action = array(
				'recipe_id' => $recipe_id,
				'post_id' => $post_id,
				'type' => $type,
				'meta' => $meta,
				'visitor_id' => self::get_visitor_id(),
				'visitor' => self::get_visitor(),
			);

			WPRM_Analytics_Database::add( $action );
		}
	}

	/**
	 * Get visitor ID.
	 *
	 * @since    6.5.0
	 */
	public static function get_visitor_id() {
		$visitor_id = isset( $_COOKIE[ 'wprm_analytics_visitor' ] ) ? sanitize_key( $_COOKIE[ 'wprm_analytics_visitor' ] ) : false;

		if ( ! $visitor_id ) {
			$visitor_id = self::set_visitor_id();
		}

		return $visitor_id;
	}

	/**
	 * Set the visitor ID.
	 *
	 * @since    6.5.0
	 */
	public static function set_visitor_id() {
		$visitor_id = uniqid( '', true );
		setcookie( 'wprm_analytics_visitor', $visitor_id, 2147483647, '/' );

		return $visitor_id;
	}

	/**
	 * Get visitor information.
	 *
	 * @since    6.5.0
	 */
	public static function get_visitor() {
		$visitor = array(
			'ip' => self::get_user_ip(),
		);

		if ( isset( $_SERVER['HTTP_USER_AGENT'] ) ) {
			$visitor['user_agent'] = $_SERVER['HTTP_USER_AGENT'];
		}

		return $visitor;
	}

	/**
	 * Get the IP address of the current user.
	 * Source: http://stackoverflow.com/questions/6717926/function-to-get-user-ip-address
	 *
	 * @since    6.5.0
	 */
	public static function get_user_ip() {
		foreach ( array( 'REMOTE_ADDR', 'HTTP_CLIENT_IP', 'HTTP_X_FORWARDED_FOR', 'HTTP_X_FORWARDED', 'HTTP_X_CLUSTER_CLIENT_IP', 'HTTP_FORWARDED_FOR', 'HTTP_FORWARDED' ) as $key ) {
			if ( array_key_exists( $key, $_SERVER ) === true ) {
				foreach ( array_map( 'trim', explode( ',', $_SERVER[ $key ] ) ) as $ip ) { // Input var ok.
					if ( filter_var( $ip, FILTER_VALIDATE_IP, FILTER_FLAG_NO_PRIV_RANGE | FILTER_FLAG_NO_RES_RANGE ) !== false ) {
						return $ip;
					}
				}
			}
		}
		return 'unknown';
	}

	/**
	 * Get optional meta that was set in the frontend.
	 *
	 * @since    6.5.0
	 */
	public static function get_frontend_meta() {
		$cookie = isset( $_COOKIE[ 'wprm_analytics_meta' ] ) ? $_COOKIE[ 'wprm_analytics_meta' ] : false;

		if ( $cookie ) {
			$decoded = json_decode( stripslashes( $_COOKIE[ 'wprm_analytics_meta' ] ), true );

			if ( $decoded ) {
				return $decoded;
			}
		}

		return array();
	}
}
