import Recipe from './Recipe/Recipe';

export default [Recipe];