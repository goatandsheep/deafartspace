<?php
/**
 * Template for recipe settings page.
 *
 * @link       http://bootstrapped.ventures
 * @since      1.0.0
 *
 * @package    WP_Recipe_Maker
 * @subpackage WP_Recipe_Maker/templates/admin
 */

?>
<div id="wprm-settings" class="wrap">Loading...</div>
